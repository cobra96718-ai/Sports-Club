# 🚌 BusGo — Bus Booking Management System

A modern, fully responsive Bus Booking System built with **React.js + Vite** (Frontend Only).  
No backend, no database, no Firebase — pure React with LocalStorage persistence.

---

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## 🔑 Demo Login

| Email | Password |
|-------|----------|
| `demo@busgo.com` | `demo123` |

> Or register any email with password ≥ 6 characters.

---

## 📁 Project Structure

```
src/
├── components/
│   ├── bus/          # SearchForm, BusCard, FilterPanel
│   ├── seat/         # SeatSelector
│   ├── ticket/       # ETicket (with QR placeholder)
│   ├── ui/           # Toast, Modal, Skeleton, Pagination, StarRating
│   └── layout/       # Navbar, Footer
├── context/
│   └── AppContext.jsx # Global state (auth, bookings, theme, toasts)
├── data/
│   └── index.js      # All mock data (40 buses, operators, offers, etc.)
├── hooks/
│   └── index.js      # useLocalStorage, useBusSearch, useFilters, usePagination, useForm
├── pages/
│   ├── Home.jsx       # Landing page
│   ├── Search.jsx     # Search results + filters
│   ├── BusDetail.jsx  # Bus detail + seat selection
│   ├── Booking.jsx    # 4-step booking flow
│   ├── Dashboard.jsx  # User dashboard
│   ├── Admin.jsx      # Admin panel
│   ├── Offers.jsx     # Promo codes & deals
│   ├── Support.jsx    # FAQ + contact + live chat
│   ├── Notifications.jsx
│   └── Auth.jsx       # Login + Register
├── utils/
│   └── index.js       # formatCurrency, calcTax, applyPromo, etc.
└── styles/
    └── globals.css    # Tailwind + custom classes
```

---

## ✨ Features

### Core
- 🔍 **Bus Search** — city autocomplete, date picker, passenger count
- 🎛️ **Advanced Filters** — price, type, departure time, rating + 6 sort options
- 💺 **Interactive Seat Map** — available/booked/selected/ladies seats
- 📋 **4-Step Booking** — passengers → summary → payment → confirmation
- 🎫 **E-Ticket** — QR code placeholder, download (print), share

### User
- 🔐 **Auth** — login/register with form validation
- 📊 **Dashboard** — overview, my bookings, profile, history
- 🔄 **Cancel & Rebook** — mock cancellation with refund message
- 🔔 **Notifications** — booking confirmations, offers, reminders

### Admin
- 📈 **Statistics** — users, bookings, revenue, buses
- 🚌 **Bus Management** — table with search, add bus modal
- 📋 **Booking Management** — full booking table with search/filter
- 🗺️ **Route Management** — route cards with status

### UI/UX
- 🌙 **Dark / Light Mode** — persisted to localStorage
- 📱 **Fully Responsive** — mobile, tablet, desktop
- ✨ **Framer Motion** — page transitions, hover effects, stagger animations
- 💀 **Loading Skeletons** — for search results
- 🍞 **Toast Notifications** — success, error, info, warning
- 🏷️ **Promo Codes** — apply discounts at checkout (FIRST50, STUDENT20, etc.)
- 💬 **Live Chat UI** — mock chatbot on support page

---

## 🛠 Tech Stack

| Technology | Purpose |
|-----------|---------|
| React 18 | UI framework |
| Vite | Build tool |
| React Router DOM v6 | Routing + protected routes |
| Context API | Global state management |
| LocalStorage | Data persistence |
| Framer Motion | Animations |
| Tailwind CSS | Styling |
| React Icons | Icon library |

---

## 🎨 Promo Codes to Test

| Code | Discount |
|------|----------|
| `FIRST50` | 50% off (min ₹200) |
| `STUDENT20` | 20% off (min ₹300) |
| `FLAT100` | ₹100 off (min ₹500) |
| `WEEKEND15` | 15% off (min ₹400) |
| `CASHBACK200` | ₹200 off (min ₹800) |
| `MONSOON30` | 30% off (min ₹250) |

---

## 📄 License

MIT — free to use and modify.
